import xbmcaddon

MainBase = 'https://goo.gl/OCvK6B'
addon = xbmcaddon.Addon('plugin.video.Dizz0 TV')